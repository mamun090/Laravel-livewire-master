<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
	// menginputkan data dengan field banyak sekaligus
    protected $guarded = [];
}
